/* var escola = "Gama Academy";
var cursos = "Curso de javacript";
var separador = " - ";

var nome = prompt("Seja bem vindo! Digite seu nome");
document.write("Seja bem vindo " + nome); */

function mensagem(){
    alert("Blz mano?");
}

function validar(){
    var nome=formulario.nome.value;
    var email=formulario.email.value;
    var senha=formulario.senha.value;

    if (nome == ""){
        alert("Preencha o campo Nome!");
        formulario.nome.focus();
        return false;
    }

    if (email == "" || email.indexOf('@') == -1 || (email.length-1 == email.indexOf('@'))){
        alert("Preencha o campo Email corretamente!")
        formulario.email.focus();
        return false;
    }

    if (senha.length < 6){
        alert("Senha tem que ter mínimo de 6 caracteres!")
        formulario.senha.focus();
        return false;
    }

    alert("Muito obrigado " + nome + "\nenviaremos a resposta para seu email " + email);
}

function mostrarAlerta(){
    alert("Olá eu sou um alerta");
}

function validarNumero(){
    var numero = parseInt(prompt("Digite um número"));

    if ((numero % 2) == 0){
        alert("Este número é par!");
    } else {
        alert("Este número é ímpar!");
    }
}

